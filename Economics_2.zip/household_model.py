"""
household_model.py  —  Derive household classes from Gini coefficient + GDP.

Given:
  - Gini coefficient G
  - Base GDP (from goods DB)
  - Consumption share of GDP
  - Savings rate
  - Total households N
  - Class percentile cutoffs (low/middle/high)

Produces:
  - Count of households per class
  - Average income per class
  - Individual Household objects for simulation
"""
import random
import numpy as np
from dataclasses import dataclass, field
from typing import Dict
from scipy.stats import norm, lognorm

# COICOP basket weights (fraction of disposable income per division)
COICOP_WEIGHTS: Dict[str, float] = {
    "01": 0.136, "02": 0.014, "03": 0.030, "04": 0.175,
    "05": 0.055, "06": 0.073, "07": 0.151, "08": 0.035,
    "09": 0.055, "10": 0.030, "11": 0.065, "12": 0.035,
}

ELASTICITY: Dict[str, float] = {
    "01": -0.3, "02": -0.5, "03": -0.8, "04": -0.2,
    "05": -1.1, "06": -0.2, "07": -0.6, "08": -0.7,
    "09": -1.3, "10": -0.4, "11": -0.9, "12": -0.5,
}


@dataclass
class Household:
    hh_id: int
    income: float           # monthly gross income
    hh_class: str           # 'low', 'middle', 'high'
    savings_rate: float = 0.10
    basket: Dict[str, float] = field(default_factory=dict)

    def __post_init__(self):
        if not self.basket:
            # High class spends more on recreation/restaurants, less on food share
            w = dict(COICOP_WEIGHTS)
            if self.hh_class == "high":
                w["01"] *= 0.7; w["09"] *= 1.5; w["11"] *= 1.4; w["12"] *= 1.6
            elif self.hh_class == "low":
                w["01"] *= 1.4; w["04"] *= 1.2; w["09"] *= 0.5; w["12"] *= 0.3
            total = sum(w.values())
            self.basket = {k: v/total for k,v in w.items()}

    @property
    def disposable_income(self) -> float:
        return self.income * (1 - self.savings_rate)

    def demand_for(self, division: str, price_index: float, base_price_index: float) -> float:
        base_spend = self.disposable_income * self.basket.get(division, 0.0)
        if base_price_index <= 0:
            return base_spend
        price_ratio = price_index / base_price_index
        e = ELASTICITY.get(division, -0.5)
        qty_adj = max(0.05, 1 + e * (price_ratio - 1))
        return base_spend * qty_adj


def gini_to_sigma(gini: float) -> float:
    """Convert Gini coefficient to log-normal shape parameter σ."""
    # Gini = 2·Φ(σ/√2) − 1  →  σ = √2·Φ⁻¹((G+1)/2)
    return float(np.sqrt(2) * norm.ppf((gini + 1) / 2))


def lognormal_conditional_mean(mu_ln: float, sigma: float,
                               lo: float, hi: float) -> float:
    """E[X | lo ≤ X ≤ hi] for X ~ LogNormal(mu_ln, sigma)."""
    mu2 = mu_ln + sigma**2
    inf = 1e18
    lo_safe = lo if lo > 0 else 1e-9
    hi_safe = hi if hi < inf else inf

    if hi >= inf:
        num = norm.sf((np.log(lo_safe) - mu2) / sigma)
        den = norm.sf((np.log(lo_safe) - mu_ln) / sigma)
    else:
        num = (norm.cdf((np.log(hi_safe) - mu2) / sigma) -
               norm.cdf((np.log(lo_safe) - mu2) / sigma))
        den = (norm.cdf((np.log(hi_safe) - mu_ln) / sigma) -
               norm.cdf((np.log(lo_safe) - mu_ln) / sigma))

    return float(np.exp(mu_ln + sigma**2 / 2) * num / max(den, 1e-12))


def derive_household_classes(
    gini: float,
    total_households: int,
    base_gdp: float,
    consumption_share: float = 0.60,
    savings_rate: float = 0.10,
    low_pct: float = 40.0,
    mid_pct: float = 80.0,
) -> dict:
    """
    Returns a dict with class stats and all individual incomes.

    Output structure:
    {
      'base_gdp': ...,
      'total_income': ...,
      'avg_income': ...,
      'sigma': ...,
      'classes': {
        'low':    {'count', 'avg_income', 'income_range', 'share_of_total_income'},
        'middle': {...},
        'high':   {...},
      },
      'incomes': [float, ...]   # one per household, sorted ascending
    }
    """
    # Total household income derived from GDP
    total_consumption = base_gdp * consumption_share
    total_income = total_consumption / (1 - savings_rate)
    avg_monthly_income = (total_income / total_households) / 12

    # Log-normal parameters
    sigma = gini_to_sigma(gini)
    mu_ln = np.log(avg_monthly_income) - sigma**2 / 2

    dist = lognorm(s=sigma, scale=np.exp(mu_ln))

    # Percentile income thresholds
    lo_thresh = float(dist.ppf(low_pct / 100))
    mid_thresh = float(dist.ppf(mid_pct / 100))

    # Class counts
    n_low    = round(total_households * low_pct / 100)
    n_middle = round(total_households * (mid_pct - low_pct) / 100)
    n_high   = total_households - n_low - n_middle

    # Average incomes per class (conditional expectation)
    avg_low    = lognormal_conditional_mean(mu_ln, sigma, 0,          lo_thresh)
    avg_middle = lognormal_conditional_mean(mu_ln, sigma, lo_thresh,  mid_thresh)
    avg_high   = lognormal_conditional_mean(mu_ln, sigma, mid_thresh, 1e18)

    # Verify: weighted average ≈ avg_monthly_income
    implied_avg = (n_low*avg_low + n_middle*avg_middle + n_high*avg_high) / total_households

    # Sample actual incomes for each household
    rng = np.random.default_rng(42)
    incomes_low    = np.sort(rng.lognormal(mu_ln, sigma, n_low * 5))
    incomes_low    = incomes_low[incomes_low <= lo_thresh][:n_low]
    incomes_middle = np.sort(rng.lognormal(mu_ln, sigma, n_middle * 5))
    incomes_middle = incomes_middle[(incomes_middle > lo_thresh) &
                                    (incomes_middle <= mid_thresh)][:n_middle]
    incomes_high   = np.sort(rng.lognormal(mu_ln, sigma, n_high * 10))
    incomes_high   = incomes_high[incomes_high > mid_thresh][:n_high]

    # Pad if sampling didn't get enough (edge case)
    def pad(arr, n, mean):
        if len(arr) < n:
            extra = rng.lognormal(np.log(mean), sigma*0.1, n - len(arr))
            arr = np.concatenate([arr, extra])
        return arr[:n]

    incomes_low    = pad(incomes_low,    n_low,    avg_low)
    incomes_middle = pad(incomes_middle, n_middle, avg_middle)
    incomes_high   = pad(incomes_high,   n_high,   avg_high)

    all_incomes = np.concatenate([incomes_low, incomes_middle, incomes_high])
    total_income_share = all_incomes.sum()

    classes = {
        "low": {
            "count":                n_low,
            "avg_income":           round(avg_low, 2),
            "income_range":         (0, round(lo_thresh, 2)),
            "share_of_total_income": round(incomes_low.sum() / total_income_share * 100, 1),
        },
        "middle": {
            "count":                n_middle,
            "avg_income":           round(avg_middle, 2),
            "income_range":         (round(lo_thresh, 2), round(mid_thresh, 2)),
            "share_of_total_income": round(incomes_middle.sum() / total_income_share * 100, 1),
        },
        "high": {
            "count":                n_high,
            "avg_income":           round(avg_high, 2),
            "income_range":         (round(mid_thresh, 2), None),
            "share_of_total_income": round(incomes_high.sum() / total_income_share * 100, 1),
        },
    }

    return {
        "gini":            gini,
        "sigma":           round(sigma, 4),
        "base_gdp":        round(base_gdp, 2),
        "total_income":    round(total_income, 2),
        "avg_monthly_income": round(avg_monthly_income, 2),
        "implied_avg":     round(implied_avg, 2),
        "classes":         classes,
        "incomes_by_class": {
            "low": incomes_low,
            "middle": incomes_middle,
            "high": incomes_high,
        },
    }


def build_households(
    hh_stats: dict,
    savings_rate: float = 0.10,
    rng_seed: int = 42,
) -> list:
    """Build Household objects from derive_household_classes output."""
    rng = random.Random(rng_seed)
    households = []
    hh_id = 0
    for cls_name, cls_incomes in hh_stats["incomes_by_class"].items():
        for income in cls_incomes:
            sr = max(0.02, min(0.40, rng.gauss(savings_rate, savings_rate * 0.2)))
            hh = Household(hh_id=hh_id, income=float(income),
                           hh_class=cls_name, savings_rate=sr)
            households.append(hh)
            hh_id += 1
    return households


def print_household_report(stats: dict):
    print("\n── Household Distribution ──────────────────────────────────────")
    print(f"  Gini coefficient   : {stats['gini']:.3f}  (σ={stats['sigma']:.3f})")
    print(f"  Base GDP           : ${stats['base_gdp']:,.0f}")
    print(f"  Total annual income: ${stats['total_income']:,.0f}")
    print(f"  Avg monthly income : ${stats['avg_monthly_income']:,.0f}")
    print()
    print(f"  {'Class':<10} {'Count':>7} {'Avg Monthly Income':>20} "
          f"{'Income Range':>28} {'Income Share':>13}")
    print(f"  {'-'*82}")
    for cls, info in stats["classes"].items():
        lo, hi = info["income_range"]
        rng_str = f"${lo:,.0f} – {'∞' if hi is None else f'${hi:,.0f}'}"
        print(f"  {cls.capitalize():<10} {info['count']:>7,} "
              f"  ${info['avg_income']:>17,.2f}   {rng_str:>28} "
              f"  {info['share_of_total_income']:>8.1f}%")
    print("────────────────────────────────────────────────────────────────\n")
